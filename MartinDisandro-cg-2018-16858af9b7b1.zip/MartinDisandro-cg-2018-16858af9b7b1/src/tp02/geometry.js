class Geometry {
  constructor (vertices, faces) {
    this.vertices = vertices
    this.faces = faces
  }
}

module.exports = Geometry
