class Material {
  constructor (color01, shininess) {
    this.color = [color01[0] * 255, color01[1] * 255, color01[2] * 255]
    this.shininess = shininess //* 128
  }

  get diffuse () {
    return [this.color[0] * 0.5 / 255, this.color[1] * 0.5 / 255, this.color[2] * 0.5 / 255]
  }
  get specular () {
    // return [this.color[0] * 0.7 / 255, this.color[1] * 0.7 / 255, this.color[2] * 0.7 / 255]
    return [this.color[0] / 255, this.color[1] / 255, this.color[2] / 255]
  }
}

module.exports = Material
