const transpose = (a) => {
  // throw new Error('Not implemented')
  // console.log('a vale: ' + a)
  let m = []
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      m[i * 4 + j] = a[j * 4 + i]
    }
  }
  // console.log('m vale: ' + m)
  return m
}
const multiply = (a, b) => {
  // throw new Error('Not implemented')
  // Multiplico por la transpuesta de B de manera fila x fila
  let tb = transpose(b)
  let c = []
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      c[i * 4 + j] = 0
      for (let k = 0; k < 4; k++) {
        c[i * 4 + j] += a[i * 4 + k] * tb[j * 4 + k]
      }
    }
  }
  return c
}

module.exports = {
  transpose,
  multiply
}

// Implementar el modulo mat4 para vectores de 16 componentes interpretados como column major order matrices
// transpose(A), donde A es una vector de 16 elementos y devolver la transpuesta de A
// multiply(A,B), donde A y B son vectores de 16 elementos y devolver la multiplicación de A por B
// Nota: la multiplicación de matrices no es conmutativa
