/*
 * Dale's framework for WebGL applications.
 * Formats: 3D model format parsing, etc.
 */

// let DGL = {}

/*
 * Parse a 3D model description in WaveFront OBJ format.
 * [params]
 * src: The source of the description.
 * smooth: Decide whether to average the normals to give a smooth lighting or
 *         not.
 * [return]
 * An object describing the mesh parsed from the description.
 */
function parseObj (src, smooth) {
  smooth = smooth || false

  let lines = src.split('\n')
  let vlines = lines.filter(
    function (l) { return l[0] === 'v' }
  )
  let flines = lines.filter(
    function (l) { return l[0] === 'f' }
  )

  let verts = new Array(3 * vlines.length)

  for (let i = 0; i < vlines.length; ++i) {
    let posStr = vlines[i].split(' ')
    verts[3 * i + 0] = parseFloat(posStr[1])
    verts[3 * i + 1] = parseFloat(posStr[2])
    verts[3 * i + 2] = parseFloat(posStr[3])
  }

  let pos = new Array(3 * 3 * flines.length)
  let idx = new Array(3 * flines.length)
  let normals = new Array(3 * 3 * flines.length)
  let normalsAvg = new Array(3 * vlines.length)

  for (let i = 0; i < normalsAvg.length; ++i) {
    normalsAvg[i] = 0.0
  }

  for (let i = 0; i < flines.length; ++i) {
    let triStr = flines[i].split(' ')

    let idx0 = parseInt(triStr[1]) - 1
    let pos0 = verts.slice(idx0 * 3, idx0 * 3 + 3)
    pos[(i * 3 + 0) * 3 + 0] = pos0[0]
    pos[(i * 3 + 0) * 3 + 1] = pos0[1]
    pos[(i * 3 + 0) * 3 + 2] = pos0[2]
    idx[i * 3 + 0] = i * 3 + 0

    let idx1 = parseInt(triStr[2]) - 1
    let pos1 = verts.slice(idx1 * 3, idx1 * 3 + 3)
    pos[(i * 3 + 1) * 3 + 0] = pos1[0]
    pos[(i * 3 + 1) * 3 + 1] = pos1[1]
    pos[(i * 3 + 1) * 3 + 2] = pos1[2]
    idx[i * 3 + 1] = i * 3 + 1

    let idx2 = parseInt(triStr[3]) - 1
    let pos2 = verts.slice(idx2 * 3, idx2 * 3 + 3)
    pos[(i * 3 + 2) * 3 + 0] = pos2[0]
    pos[(i * 3 + 2) * 3 + 1] = pos2[1]
    pos[(i * 3 + 2) * 3 + 2] = pos2[2]
    idx[i * 3 + 2] = i * 3 + 2

    let n = triangleNormal(pos0, pos1, pos2)

    if (smooth) {
      normalsAvg[idx0 * 3 + 0] += n[0]
      normalsAvg[idx0 * 3 + 1] += n[1]
      normalsAvg[idx0 * 3 + 2] += n[2]
      normalsAvg[idx1 * 3 + 0] += n[0]
      normalsAvg[idx1 * 3 + 1] += n[1]
      normalsAvg[idx1 * 3 + 2] += n[2]
      normalsAvg[idx2 * 3 + 0] += n[0]
      normalsAvg[idx2 * 3 + 1] += n[1]
      normalsAvg[idx2 * 3 + 2] += n[2]
    } else {
      normals[(i * 3 + 0) * 3 + 0] = n[0]
      normals[(i * 3 + 0) * 3 + 1] = n[1]
      normals[(i * 3 + 0) * 3 + 2] = n[2]
      normals[(i * 3 + 1) * 3 + 0] = n[0]
      normals[(i * 3 + 1) * 3 + 1] = n[1]
      normals[(i * 3 + 1) * 3 + 2] = n[2]
      normals[(i * 3 + 2) * 3 + 0] = n[0]
      normals[(i * 3 + 2) * 3 + 1] = n[1]
      normals[(i * 3 + 2) * 3 + 2] = n[2]
    }
  }

  if (smooth) {
    for (let i = 0; i < flines.length; ++i) {
      let triStr = flines[i].split(' ')

      let idx0 = parseInt(triStr[1]) - 1
      let idx1 = parseInt(triStr[2]) - 1
      let idx2 = parseInt(triStr[3]) - 1

      let n0 = v3normalize(normalsAvg.slice(3 * idx0, 3 * idx0 + 3))
      let n1 = v3normalize(normalsAvg.slice(3 * idx1, 3 * idx1 + 3))
      let n2 = v3normalize(normalsAvg.slice(3 * idx2, 3 * idx2 + 3))

      normals[(i * 3 + 0) * 3 + 0] = n0[0]
      normals[(i * 3 + 0) * 3 + 1] = n0[1]
      normals[(i * 3 + 0) * 3 + 2] = n0[2]
      normals[(i * 3 + 1) * 3 + 0] = n1[0]
      normals[(i * 3 + 1) * 3 + 1] = n1[1]
      normals[(i * 3 + 1) * 3 + 2] = n1[2]
      normals[(i * 3 + 2) * 3 + 0] = n2[0]
      normals[(i * 3 + 2) * 3 + 1] = n2[1]
      normals[(i * 3 + 2) * 3 + 2] = n2[2]
    }
  }

  return {
    pos: pos,
    idx: idx,
    normals: normals,
    mode: 'TRIANGLES'
  }
  /*
  * A utility function to compute the normal of a triangle specified by
  * its vertices in counterclockwise order.
  * [params]
  * p0: The first vertex.
  * p1: The second vertex.
  * p2: The third vertex.
  * [return]
  * The normal of the triangle.
  */
}

function triangleNormal (p0, p1, p2) {
  let v1 = v3sub(p1, p0)
  let v2 = v3sub(p2, p0)
  return v3normalize(v3cross(v1, v2))
}

/*
 * Compute the normalized vector of the vector. The original vector is not modified.
 * [params]
 * v: The vector.
 * [return]
 * The normalized vector of the vector.
 */
function v3normalize (v) {
  var norm = v3norm(v)
  if (norm === 0.0) return [0.0, 0.0, 0.0]
  else return [v[0] / norm, v[1] / norm, v[2] / norm]
}

/*
 * Compute the difference of two 3-D vectors. The original vector is not modified.
 * [params]
 * v1: The vector to be subtracted from.
 * v2: The vector to be subtracted by.
 * [return]
 * The difference of the two vectors.
 */
function v3sub (v1, v2) {
  return [v1[0] - v2[0], v1[1] - v2[1], v1[2] - v2[2]]
}

/*
 * Compute the cross product of two 3-D vectors. The original vector is not modified.
 * [params]
 * v1: The first vector.
 * v2: The second vector.
 * [return]
 * The cross product of the two vectors.
 */
function v3cross (v1, v2) {
  return [
    v1[1] * v2[2] - v1[2] * v2[1],
    v1[2] * v2[0] - v1[0] * v2[2],
    v1[0] * v2[1] - v1[1] * v2[0]
  ]
}

/*
 * Compute the magnitude of the vector.
 * [params]
 * v: The vector.
 * [return]
 * The magnitude of the vector.
 */
function v3norm (v) {
  return Math.sqrt(v3dot(v, v))
}

/*
 * Compute the dot product of two 3-D vectors. The original vector is not modified.
 * [params]
 * v1: The first vector.
 * v2: The second vector.
 * [return]
 * The dot product of the two vectors.
 */
function v3dot (v1, v2) {
  return v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]
}

module.exports = parseObj
