const Geometry = require('../geometry')
class Grid extends Geometry {
  constructor () {
    const vertices = [
      0, 0, 0,
      10, 0, 0,
      0, 10, 0,
      0, 0, 10
    ]
    const indices = [
      0, 1,
      0, 2,
      0, 3
    ]
    super(vertices, indices)
  }
}

module.exports = Grid
