const glMatrix = require('gl-matrix')

class Camera {
  constructor (eyeX = 5, eyeY = 5, eyeZ = 5, centerX = 0, centerY = 0, centerZ = 0, upX = 0, upY = 1, upZ = 0) {
    this.eyeX = eyeX
    this.eyeY = eyeY
    this.eyeZ = eyeZ
    this.centerX = centerX
    this.centerY = centerY
    this.centerZ = centerZ
    this.upX = upX
    this.upY = upY
    this.upZ = upZ
    this.distance = 1.5
    this.pitch = 0 // x
    this.yaw = 0 // y
    this.roll = 0 // z
    this.quatMatrix = glMatrix.mat4.create()
    this.q = glMatrix.quat.create()
    this.viewMatrix = glMatrix.mat4.create()
    this.inversa = glMatrix.mat4.create()
  }

  getViewMatrix () {
    glMatrix.mat4.lookAt(this.viewMatrix,
      [this.eyeX * this.distance, this.eyeY * this.distance, this.eyeZ * this.distance],
      [this.centerX, this.centerY, this.centerZ],
      [this.upX, this.upY, this.upZ])

    // rotacion con quaternions
    glMatrix.quat.fromEuler(this.q, this.pitch, this.yaw, this.roll)
    glMatrix.mat4.fromQuat(this.quatMatrix, this.q)
    glMatrix.mat4.multiply(this.viewMatrix, this.viewMatrix, this.quatMatrix)

    return this.viewMatrix
  }

  get eyeView () {
    glMatrix.mat4.invert(this.inversa, this.viewMatrix)
    return [this.inversa[12], this.inversa[13], this.inversa[14]]
  }
}

module.exports = Camera
