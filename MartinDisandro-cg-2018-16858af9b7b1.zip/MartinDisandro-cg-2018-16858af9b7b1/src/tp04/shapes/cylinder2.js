const RegularConvexPolygonGeometry = require('../regularConvexPolygonGeometry')
const Geometry = require('../geometry')
const Vec3 = require('../vec3')

class Cylinder extends Geometry {
  constructor () {
    const edgesOfFace = 32
    const height = Math.sqrt(2) / 2
    // const height = 1
    let bottom = new RegularConvexPolygonGeometry(edgesOfFace, -height)
    let top = new RegularConvexPolygonGeometry(edgesOfFace, height)

    let vertices = []
    vertices.push(...bottom.vertices)
    vertices.push(...top.vertices)
    let v = []
    let b = []
    let t = []
    for (let i = 0; i < vertices.length; i += 3) {
      v.push([
        vertices[i],
        vertices[i + 1],
        vertices[i + 2],
      ])
    }
    for (let i = 0; i < bottom.vertices.length; i += 3) {
      b.push([
        bottom.vertices[i],
        bottom.vertices[i + 1],
        bottom.vertices[i + 2],
      ])
      t.push([
        top.vertices[i],
        top.vertices[i + 1],
        top.vertices[i + 2],
      ])
    }
    let indices = []
    indices.push(...bottom.indices)
    for (let i = 0; i < top.indices.length; i++) {
      indices.push(top.indices[i] + edgesOfFace)
    }

    for (let k = edgesOfFace * 2, i = 0; i < edgesOfFace; i++) {
      indices.push(k)
      indices.push(k + 1)
      indices.push(k + 2)
      indices.push(k)
      indices.push(k + 2)
      indices.push(k + 3)
      k += 4
    }

    for (let i = 0; i < b.length - 1; i++) {
      v.push(b[i + 0])
      v.push(b[i + 1])
      v.push(t[i + 1])
      v.push(t[i + 0])

      vertices.push(...b[i + 0])
      vertices.push(...b[i + 1])
      vertices.push(...t[i + 1])
      vertices.push(...t[i + 0])
    }
    v.push(b[b.length - 1])
    v.push(b[0])
    v.push(t[0])
    v.push(t[b.length - 1])

    vertices.push(...b[b.length - 1])
    vertices.push(...b[0])
    vertices.push(...t[0])
    vertices.push(...t[b.length - 1])

    // NORMALS
    let normals = []
    let aux = []
    // BOTTOM
    for (let i = 0; i < b.length - 2; i++) {
      aux = Vec3.normal(b[i], b[i + 1], b[i + 2])
      normals.push(-1 * aux[0], -1 * aux[1], -1 * aux[2])
    }
    aux = Vec3.normal(
      b[b.length - 2],
      b[b.length - 1],
      b[0]
    )
    normals.push(-1 * aux[0], -1 * aux[1], -1 * aux[2])
    aux = Vec3.normal(
      b[b.length - 1],
      b[0],
      b[1]
    )
    normals.push(-1 * aux[0], -1 * aux[1], -1 * aux[2])
    // TOP
    for (let i = 0; i < t.length - 2; i++) {
      aux = Vec3.normal(t[i], t[i + 1], t[i + 2])
      normals.push(...aux)
    }
    aux = Vec3.normal(
      t[t.length - 2],
      t[t.length - 1],
      t[0]
    )
    normals.push(...aux)
    aux = Vec3.normal(
      t[t.length - 1],
      t[0],
      t[1],
    )
    normals.push(...aux)

    // SIDES
    for (let i = edgesOfFace * 2; i < v.length - 2; i += 4) {
      aux = Vec3.normal(v[i], v[i + 1], v[i + 2])
      normals.push(...aux)

      aux = Vec3.normal(v[i + 1], v[i + 2], v[i + 3])
      normals.push(...aux)

      aux = Vec3.normal(v[i + 2], v[i + 3], v[i])
      normals.push(...aux)

      aux = Vec3.normal(v[i + 3], v[i], v[i + 1])
      normals.push(...aux)
    }

    // console.log('vertices', vertices)
    // console.log('v', v)
    // console.log('indices', indices)
    // console.log('normals', normals)
    super(vertices, indices, normals)
  }
}
module.exports = Cylinder
