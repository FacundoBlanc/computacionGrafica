class RGBA {
  constructor (r = 1, g = 1, b = 1, a = 1) {
    this.r = r
    this.g = g
    this.b = b
    this.a = a
  }
  vec4 () {
    return [ this.r, this.g, this.b, this.a ]
  }
  vec3 () {
    return [ this.r, this.g, this.b ]
  }
}

module.exports = RGBA
