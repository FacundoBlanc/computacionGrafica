const normalize = (a) => {
  // throw new Error('Not implemented')
  // magnitud = sqrt( a[0]^2 + a[1]^2 + a[2]^2)
  const sumaCuadrados = Math.pow(a[0], 2) + Math.pow(a[1], 2) + Math.pow(a[2], 2)
  const magnitud = Math.sqrt(sumaCuadrados)
  a[0] /= magnitud
  a[1] /= magnitud
  a[2] /= magnitud
  return a
}

const cross = (a, b) => {
  // throw new Error('Not implemented')
  // i   j   k
  // a0  a1  a2
  // b0  b1  b2
  // c[0] =  a1*b2 + a2*b1
  // c[1] =  a0*b2 + a2*b0
  // c[2] =  a0*b1 + a1*b0
  let c = []
  c[0] = a[1] * b[2] - a[2] * b[1]
  c[1] = -(a[0] * b[2] - a[2] * b[0])
  c[2] = a[0] * b[1] - a[1] * b[0]
  return c
}

const normal = (a, b, c) => {
  // throw new Error('Not implemented')
  // La norma del vector normal esta dada por |ABxAC|
  const ab = [b[0] - a[0], b[1] - a[1], b[2] - a[2]]
  const ac = [c[0] - a[0], c[1] - a[1], c[2] - a[2]]
  return normalize(cross(ab, ac))
}

module.exports = {
  normalize,
  cross,
  normal
}
