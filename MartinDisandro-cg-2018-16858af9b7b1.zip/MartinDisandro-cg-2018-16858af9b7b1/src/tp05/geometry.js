class Geometry {
  constructor (vertices, indices, normals, st) {
    this.vertices = vertices
    this.indices = indices
    this.normals = normals
    this.st = st
  }
}

module.exports = Geometry
