class Mesh {
  constructor (geometry, material) {
    this.geometry = geometry
    this.material = material
    this.vertexBO = new Float32Array(geometry.vertices)

    let indexes = []
    let edges = geometry.vertices.length / 2
    let k = 0
    for (let i = 0; i < edges - 2; i++) {
      indexes[k] = 0
      indexes[k + 1] = i + 1
      indexes[k + 2] = i + 2
      k += 3
    }
    this.indexBO = new Uint16Array(indexes)
  }
  addMesh (mesh) {
    this.mesh = mesh
  }
  getModelMatrix () {
  }
}

module.exports = Mesh
