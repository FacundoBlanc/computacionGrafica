const RegularConvexPolygonGeometry = require('../regularConvexPolygonGeometry')
const Geometry = require('../geometry')

class Cylinder extends Geometry {
  constructor (edges, cylinder = true) {
    const edgesOfFace = edges
    const height = Math.sqrt(2) / 2
    let bottom = new RegularConvexPolygonGeometry(edgesOfFace, -height)
    let top = new Geometry([0, 1, 0], [])

    let indices = bottom.indices

    if (cylinder === true) {
      top = new RegularConvexPolygonGeometry(edgesOfFace, height)

      for (let i = 0; i < top.indices.length; i++) {
        indices.push(top.indices[i] + edgesOfFace)
      }

      for (let i = 0; i < edgesOfFace; i++) {
        indices.push(i)
        indices.push(i + edgesOfFace)
        indices.push(i === edgesOfFace - 1 ? edgesOfFace : i + edgesOfFace + 1)

        indices.push(i)
        indices.push(i === edgesOfFace - 1 ? edgesOfFace : i + edgesOfFace + 1)
        indices.push(i === edgesOfFace - 1 ? 0 : i + 1)
      }
    } else {
      for (let i = 0; i < edgesOfFace; i++) {
        indices.push(i)
        indices.push(i === edgesOfFace - 1 ? 0 : i + 1)
        indices.push(edgesOfFace)
      }
    }
    let vertices = bottom.vertices
    vertices.push(...top.vertices)

    super(vertices, indices)
  }
}

module.exports = Cylinder
