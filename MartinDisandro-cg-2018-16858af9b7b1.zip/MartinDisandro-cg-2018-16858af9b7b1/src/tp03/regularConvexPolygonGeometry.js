const Geometry = require('./geometry')

class RegularConvexPolygonGeometry extends Geometry {
  constructor (edges, h) {
    // let alfa = 180 / edges
    let alfa = 45
    const grados = 360 / edges
    let vertices = []

    for (let i = 0; i < edges * 3; i += 3) {
      vertices[i] = Math.cos(Math.PI * alfa / 180.0)
      vertices[i + 1] = h
      vertices[i + 2] = Math.sin(Math.PI * alfa / 180.0)
      alfa += grados
    }
    // console.log(grados)
    // console.log(v)
    let indices = []
    // let edges = vertices.length / 3
    let k = 0
    for (let i = 0; i < edges - 2; i++) {
      indices[k] = 0
      indices[k + 1] = i + 1
      indices[k + 2] = i + 2
      k += 3
    }
    super(vertices, indices)
  }
}
module.exports = RegularConvexPolygonGeometry
