console.log('tp05')

const dat = require('dat.gui/build/dat.gui')
const WebGLRenderer = require('./webGLRenderer')
const Scene = require('./scene')
const Mesh = require('./mesh')
const PerspectiveCamera = require('./camera/perspectiveCamera')
const Line = require('./shapes/line')
const Floor = require('./shapes/floor')
const Cube = require('./shapes/cube')
const Cylinder = require('./shapes/cylinder2')
const Sphere = require('./shapes/sphere')
const AmbientLight = require('./lights/ambientLight')
const DirectionalLight = require('./lights/directionalLight')
const PointLight = require('./lights/pointLight')
const SpotLight = require('./lights/spotLight')
const Material = require('./material')

let canvas = document.getElementById('c')
// canvas.width = window.innerWidth
// canvas.height = window.innerHeight
// document.addEventListener('click', function (event) {
//   console.log('click')
//   console.log(event)
// })

let webGLRenderer = new WebGLRenderer(canvas)
let ambientLight = new AmbientLight([1, 1, 1], 0.5, true)
let directionalLight = new DirectionalLight([1, 1, 0], [-1, 1, -1], true)
let pointLight1 = new PointLight([1, 0, 0], [6, 0, 0], false)
let pointLight2 = new PointLight([0, 0, 1], [-2, 0, 3], false)
let pointLights = [pointLight1, pointLight2]
let spotLight = new SpotLight([0, 1, 0], [0, 5, 0], [0, -1, 0], false)

let scene = new Scene([0.1, 0.1, 0.1, 1], ambientLight, directionalLight, pointLights, spotLight)

// Axes
scene.addMesh(new Mesh(new Line([0, 0, 0, 10, 0, 0]), [1, 0, 0]))
scene.addMesh(new Mesh(new Line([0, 0, 0, 0, 10, 0]), [0, 1, 0]))
scene.addMesh(new Mesh(new Line([0, 0, 0, 0, 0, 10]), [0, 0, 1]))
// Grid
for (let i = -10; i <= 10; i++) {
  scene.addMesh(new Mesh(new Line([i, 0, -10, i, 0, 10]), [0.5, 0.5, 0.5]))
  scene.addMesh(new Mesh(new Line([-10, 0, i, 10, 0, i]), [0.5, 0.5, 0.5]))
}

// Mesh 45
// Floor 45
scene.addMesh(new Mesh(new Floor(), new Material([1, 1, 1], 25, './textures/iua-256x256.png'), true))
scene.meshes[45].setPosition([0, -1, 0])
scene.meshes[45].active = true
// scene.meshes[45].setRotation([155, 0, 155])
// Cube, mesh 46
scene.addMesh(new Mesh(new Cube(), new Material([1, 1, 1], 25, './textures/firefox-256x256.png'), true))
scene.meshes[46].setPosition([2, 1, -2])
scene.meshes[46].active = true
// scene.meshes[46].setRotation([45, 0, 15])
// Cylinder, mesh 47
scene.addMesh(new Mesh(new Cylinder(), new Material([1, 1, 1], 25, './textures/earthmap-1024x512.jpg'), true))
scene.meshes[47].active = false
// Sphere, mesh 48
scene.addMesh(new Mesh(new Sphere(1), new Material([1, 1, 1], 25, './textures/earthmap-1024x512.jpg'), true))
scene.meshes[48].setPosition([-2, 2, 2])
scene.meshes[48].active = true
// POINT LIGHTS
scene.addMesh(new Mesh(new Sphere(0.5), [1, 0, 0]))
scene.addMesh(new Mesh(new Sphere(0.5), [0, 0, 1]))
// SPOT LIGHT
scene.addMesh(new Mesh(new Sphere(0.5), [0, 1, 0]))

// GUI Figures
let gui = new dat.GUI({ width: 200 })
let figureName = ['Floor', 'Cube', 'Cylinder', 'Sphere']

for (let i = 45; i < scene.meshes.length - 3; i++) {
  // gui.add(webGLRenderer, figureName[i - 45].toLowerCase())
  // gui.add(scene.meshes[i], 'active')
  // gui.add(scene.meshes[i], 'active')
  let figureFolder = gui.addFolder(figureName[i - 45])
  figureFolder.add(scene.meshes[i], 'active')
  figureFolder.add(scene.meshes[i].material, 'useTexture')

  figureFolder.add(scene.meshes[i], 'tx', -10, 10, 1)
  figureFolder.add(scene.meshes[i], 'ty', -10, 10, 0.1)
  figureFolder.add(scene.meshes[i], 'tz', -10, 10, 1)

  figureFolder.add(scene.meshes[i], 'sx', 0, 10, 1)
  figureFolder.add(scene.meshes[i], 'sy', 0, 10, 1)
  figureFolder.add(scene.meshes[i], 'sz', 0, 10, 1)

  figureFolder.add(scene.meshes[i], 'rx', 0, 360, 1)
  figureFolder.add(scene.meshes[i], 'ry', 0, 360, 1)
  figureFolder.add(scene.meshes[i], 'rz', 0, 360, 1)

  figureFolder.add(scene.meshes[i].material, 'shininess', 1, 128, 1)
  figureFolder.addColor(scene.meshes[i].material, 'color')
}

// GUI Camera
let camera = new PerspectiveCamera()
// let guiCamera = new dat.GUI({ width: 300 })
// let persCam = gui.addFolder('Perspective')
// persCam.add(camera, 'fovy', Math.PI / 180, Math.PI / 2, Math.PI / 180)
// persCam.add(camera, 'aspect', 0.1, 5, 0.1)
// persCam.add(camera, 'near', 0.001, 10, 0.1)
// persCam.add(camera, 'far', 5, 1005, 10)
let cam = gui.addFolder('Camera')
cam.add(camera, 'eyeX', -10, 10, 1)
cam.add(camera, 'eyeY', -10, 10, 1)
cam.add(camera, 'eyeZ', -10, 10, 1)
// cam.add(camera, 'centerX', -10, 10, 1)
// cam.add(camera, 'centerY', -10, 10, 1)
// cam.add(camera, 'centerZ', -10, 10, 1)
// cam.add(camera, 'upX', -10, 10, 1)
// cam.add(camera, 'upY', -10, 10, 1)
// cam.add(camera, 'upZ', -10, 10, 1)
cam.add(camera, 'distance', 0.1, 3, 0.1)
cam.add(camera, 'pitch', 0, 360, 1)
cam.add(camera, 'yaw', 0, 360, 1)
cam.add(camera, 'roll', 0, 360, 1)

// GUI Lights
let lightsGUI = new dat.GUI({ width: 200 })

let ambientLightsGUI = lightsGUI.addFolder('Ambient Light')
ambientLightsGUI.add(ambientLight, 'active')
ambientLightsGUI.add(ambientLight, 'intensity', 0.01, 1, 0.01)
ambientLightsGUI.addColor(ambientLight, 'color')

let dirLightsGUI = lightsGUI.addFolder('Directional Light')
dirLightsGUI.add(directionalLight, 'active')
dirLightsGUI.add(directionalLight, 'px', -1, 1, 0.1)
dirLightsGUI.add(directionalLight, 'py', -1, 1, 0.1)
dirLightsGUI.add(directionalLight, 'pz', -1, 1, 0.1)
dirLightsGUI.addColor(directionalLight, 'color')

let pointLight1GUI = lightsGUI.addFolder('Point Light 1')
pointLight1GUI.add(pointLight1, 'active')
pointLight1GUI.add(pointLight1, 'px', -10, 10, 0.1)
pointLight1GUI.add(pointLight1, 'py', -10, 10, 0.1)
pointLight1GUI.add(pointLight1, 'pz', -10, 10, 0.1)
pointLight1GUI.addColor(pointLight1, 'color')

let pointLight2GUI = lightsGUI.addFolder('Point Light 2')
pointLight2GUI.add(pointLight2, 'active')
pointLight2GUI.add(pointLight2, 'px', -10, 10, 0.1)
pointLight2GUI.add(pointLight2, 'py', -10, 10, 0.1)
pointLight2GUI.add(pointLight2, 'pz', -10, 10, 0.1)
pointLight2GUI.addColor(pointLight2, 'color')

let spotLight2GUI = lightsGUI.addFolder('Spot Light')
spotLight2GUI.add(spotLight, 'active')
spotLight2GUI.add(spotLight, 'px', -10, 10, 0.1)
spotLight2GUI.add(spotLight, 'py', -10, 10, 0.1)
spotLight2GUI.add(spotLight, 'pz', -10, 10, 0.1)
spotLight2GUI.add(spotLight, 'dx', -10, 10, 0.1)
spotLight2GUI.add(spotLight, 'dy', -10, 10, 0.1)
spotLight2GUI.add(spotLight, 'dz', -10, 10, 0.1)
spotLight2GUI.add(spotLight, 'cutOff', 0, 60, 1)
spotLight2GUI.add(spotLight, 'focus', 0, 10, 0.1)
spotLight2GUI.addColor(spotLight, 'color')

// LOOP Renderizado
// function render (time) {
//   webGLRenderer.render(scene, camera)
//   window.requestAnimationFrame(render)
// }
// window.requestAnimationFrame(render)

// Limitado a 20 FPS
webGLRenderer.fps = 20
webGLRenderer.limitFps = true

function renderAtCustomFps () {
  if (webGLRenderer.fps) {
    webGLRenderer.render(scene, camera)
  }
  setTimeout(function () {
    window.requestAnimationFrame(renderAtCustomFps)
  }, webGLRenderer.limitFps && webGLRenderer.fps && 1000 / webGLRenderer.fps)
}
window.requestAnimationFrame(renderAtCustomFps)
