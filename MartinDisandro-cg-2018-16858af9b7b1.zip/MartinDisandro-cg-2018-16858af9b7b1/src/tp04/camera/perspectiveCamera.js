const Camera = require('./camera')
const glMatrix = require('gl-matrix')

class PerspectiveCamera extends Camera {
  constructor (fovy = Math.PI / 4, aspect = 16 / 9, near = 0.001, far = 1000) {
    super()
    this.fovy = fovy
    this.aspect = aspect
    this.near = near
    this.far = far
    this.projectionMatrix = glMatrix.mat4.create()
  }
  getProjectionMatrix () {
    glMatrix.mat4.perspective(this.projectionMatrix, this.fovy, this.aspect, this.near, this.far)
    // roll, pitch, yaw
    // let q = glMatrix.quat.create()
    // glMatrix.quat.fromEuler(q, this.rx, this.ry, this.rz)
    // glMatrix.mat4.fromQuat(modelMatrix, q)

    return this.projectionMatrix
  }
}

module.exports = PerspectiveCamera
