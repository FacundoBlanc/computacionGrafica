var vs = require('./shaders/vs.glsl')
var fs = require('./shaders/fs.glsl')
var vsLight = require('./shaders/vs_light.glsl')
var fsLight = require('./shaders/fs_light.glsl')
const twgl = require('twgl.js')

class WebGLRenderer {
  constructor (canvas) {
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
    this.gl = twgl.getWebGLContext(document.getElementById('c'))
    this.programInfo = twgl.createProgramInfo(this.gl, [vs, fs])
    this.programLight = twgl.createProgramInfo(this.gl, [vsLight, fsLight])
    if (!this.gl) {
      console.log('Failed to get the rendering context for WebGL')
    }
    this.floor = true
    this.cube = true
    this.cylinder = false
    this.sphere = true
  }

  render (scene, camera) {
    this.gl.clearColor(...scene.clearColor)
    this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT)
    this.gl.enable(this.gl.DEPTH_TEST)
    twgl.resizeCanvasToDisplaySize(this.gl.canvas)
    // gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight)
    this.gl.viewport(0, 0, window.innerWidth, window.innerHeight)

    let mesh
    const figureNumber = 45
    // let i
    for (let i = 0; i < figureNumber; i++) {
      mesh = scene.meshes[i]
      this.draw(mesh.geometry.vertices, mesh.geometry.indices,
        mesh.material, camera, mesh.getModelMatrix(), this.gl.LINES)
    }
    // Figures
    if (this.floor) {
      mesh = scene.meshes[figureNumber]
      this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
    }
    if (this.cube) {
      mesh = scene.meshes[figureNumber + 1]
      this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
    }
    if (this.cylinder) {
      mesh = scene.meshes[figureNumber + 2]
      this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
    }
    if (this.sphere) {
      mesh = scene.meshes[figureNumber + 3]
      this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
    }
    // *************************************************************
    // POINT LIGHT ORB
    if (scene.pointLights[0].active) {
      mesh = scene.meshes[figureNumber + 4]
      mesh.setPosition([scene.pointLights[0].px, scene.pointLights[0].py, scene.pointLights[0].pz])
      mesh.material = scene.pointLights[0].specular
      this.draw(mesh.geometry.vertices, mesh.geometry.indices,
        mesh.material, camera, mesh.getModelMatrix(), this.gl.TRIANGLES)
    }

    if (scene.pointLights[1].active) {
      mesh = scene.meshes[figureNumber + 5]
      mesh.setPosition([scene.pointLights[1].px, scene.pointLights[1].py, scene.pointLights[1].pz])
      mesh.material = scene.pointLights[1].specular
      this.draw(mesh.geometry.vertices, mesh.geometry.indices,
        mesh.material, camera, mesh.getModelMatrix(), this.gl.TRIANGLES)
    }
    // SPOT LIGHT ORB
    if (scene.spotLight.active) {
      mesh = scene.meshes[figureNumber + 6]
      mesh.setPosition([scene.spotLight.px, scene.spotLight.py, scene.spotLight.pz])
      mesh.material = scene.spotLight.specular

      this.draw(mesh.geometry.vertices, mesh.geometry.indices,
        mesh.material, camera, mesh.getModelMatrix(), this.gl.TRIANGLES)
    }
  }

  draw (aPosition, indices, color, camera, modelMatrix, glType) {
    let arrays = {
      aPosition: aPosition,
      indices: indices
    }
    let bufferInfo = twgl.createBufferInfoFromArrays(this.gl, arrays)
    let uniforms = {
      uColor: color,
      uViewMatrix: camera.getViewMatrix(),
      uProjectionMatrix: camera.getProjectionMatrix(),
      uModelMatrix: modelMatrix,
    }

    this.gl.useProgram(this.programInfo.program)
    twgl.setBuffersAndAttributes(this.gl, this.programInfo, bufferInfo)
    twgl.setUniforms(this.programInfo, uniforms)
    twgl.drawBufferInfo(this.gl, bufferInfo, glType)
  }

  drawLight (mesh, camera, scene, glType) {
    let arrays = {
      aPosition: mesh.geometry.vertices,
      aNormal: mesh.geometry.normals,
      indices: mesh.geometry.indices
    }
    // let programInfo = this.programLight
    let bufferInfo = twgl.createBufferInfoFromArrays(this.gl, arrays)
    let uniforms = {
      // Vertex Shader
      uModelMatrix: mesh.getModelMatrix(),
      uNormalMatrix: mesh.getNormalMatrix(),
      uViewMatrix: camera.getViewMatrix(),
      uProjectionMatrix: camera.getProjectionMatrix(),
      // Fragment Shader
      uViewPos: camera.eyeView,

      'material.diffuse': mesh.material.diffuse,
      'material.specular': mesh.material.specular,
      'material.shininess': mesh.material.shininess,

      'ambientLight.active': scene.ambientLight.active,
      'ambientLight.color': scene.ambientLight.ambient,

      'dirLight.active': scene.directionalLight.active,
      'dirLight.direction': [scene.directionalLight.px, scene.directionalLight.py, scene.directionalLight.pz],
      'dirLight.ambient': scene.directionalLight.ambient,
      'dirLight.diffuse': scene.directionalLight.diffuse,
      'dirLight.specular': scene.directionalLight.specular,

      'pointLights[0].active': scene.pointLights[0].active,
      'pointLights[0].position': [scene.pointLights[0].px, scene.pointLights[0].py, scene.pointLights[0].pz],
      'pointLights[0].ambient': scene.pointLights[0].ambient,
      'pointLights[0].diffuse': scene.pointLights[0].diffuse,
      'pointLights[0].specular': scene.pointLights[0].specular,
      'pointLights[0].constant': scene.pointLights[0].constant,
      'pointLights[0].linear': scene.pointLights[0].linear,
      'pointLights[0].quadratic': scene.pointLights[0].quadratic,

      'pointLights[1].active': scene.pointLights[1].active,
      'pointLights[1].position': [scene.pointLights[1].px, scene.pointLights[1].py, scene.pointLights[1].pz],
      'pointLights[1].ambient': scene.pointLights[1].ambient,
      'pointLights[1].diffuse': scene.pointLights[1].diffuse,
      'pointLights[1].specular': scene.pointLights[1].specular,
      'pointLights[1].constant': scene.pointLights[1].constant,
      'pointLights[1].linear': scene.pointLights[1].linear,
      'pointLights[1].quadratic': scene.pointLights[1].quadratic,

      'spotLight.active': scene.spotLight.active,
      'spotLight.position': [scene.spotLight.px, scene.spotLight.py, scene.spotLight.pz],
      'spotLight.direction': [scene.spotLight.dx, scene.spotLight.dy, scene.spotLight.dz],
      'spotLight.cutOff': scene.spotLight.getCutOff(),
      'spotLight.outerCutOff': scene.spotLight.getOuterCutOff(),
      'spotLight.ambient': scene.spotLight.ambient,
      'spotLight.diffuse': scene.spotLight.diffuse,
      'spotLight.specular': scene.spotLight.specular,
      'spotLight.constant': scene.spotLight.constant,
      'spotLight.linear': scene.spotLight.linear,
      'spotLight.quadratic': scene.spotLight.quadratic
    }

    this.gl.useProgram(this.programLight.program)
    twgl.setBuffersAndAttributes(this.gl, this.programLight, bufferInfo)
    twgl.setUniforms(this.programLight, uniforms)
    twgl.drawBufferInfo(this.gl, bufferInfo, glType)
  }
}

module.exports = WebGLRenderer
