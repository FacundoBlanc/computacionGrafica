const Light = require('./light')

class AmbientLight extends Light {
  constructor (color, intensity, active) {
    super(color, active)
    this.intensity = intensity
  }

  get ambient () {
    return [this.color[0] * this.intensity / 255, this.color[1] * this.intensity / 255, this.color[2] * this.intensity / 255]
  }
}

module.exports = AmbientLight
