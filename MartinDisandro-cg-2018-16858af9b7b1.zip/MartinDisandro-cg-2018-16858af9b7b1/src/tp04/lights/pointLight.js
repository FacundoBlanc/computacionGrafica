const Light = require('./light')

class PointLight extends Light {
  constructor (color, position, active) {
    super(color, active)
    this.px = position[0]
    this.py = position[1]
    this.pz = position[2]
    this.constant = 1.0
    this.linear = 0.09
    this.quadratic = 0.032
  }
  get ambient () {
    return [this.color[0] * 0.2 / 255, this.color[1] * 0.2 / 255, this.color[2] * 0.2 / 255]
  }
  get diffuse () {
    return [this.color[0] * 0.5 / 255, this.color[1] * 0.5 / 255, this.color[2] * 0.5 / 255]
  }
  get specular () {
    return [this.color[0] / 255, this.color[1] / 255, this.color[2] / 255]
  }
}

module.exports = PointLight
