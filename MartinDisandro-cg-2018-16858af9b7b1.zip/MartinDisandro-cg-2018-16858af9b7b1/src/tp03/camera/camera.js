const glMatrix = require('gl-matrix')
let out = glMatrix.mat4.create()
let quatMatrix = glMatrix.mat4.create()
let q = glMatrix.quat.create()

class Camera {
  constructor (eyeX = 5, eyeY = 5, eyeZ = 5, centerX = 0, centerY = 0, centerZ = 0, upX = 0, upY = 1, upZ = 0) {
    this.eyeX = eyeX
    this.eyeY = eyeY
    this.eyeZ = eyeZ
    this.centerX = centerX
    this.centerY = centerY
    this.centerZ = centerZ
    this.upX = upX
    this.upY = upY
    this.upZ = upZ
    this.distance = 1
    this.pitch = 0 // x
    this.yaw = 0 // y
    this.roll = 0 // z
  }
  getViewMatrix () {
    let eye = [this.eyeX * this.distance, this.eyeY * this.distance, this.eyeZ * this.distance]
    let center = [this.centerX, this.centerY, this.centerZ]
    let up = [this.upX, this.upY, this.upZ]

    glMatrix.mat4.lookAt(out, eye, center, up)

    // rotacion con quaternions
    glMatrix.quat.fromEuler(q, this.pitch, this.yaw, this.roll)
    glMatrix.mat4.fromQuat(quatMatrix, q)
    glMatrix.mat4.multiply(out, out, quatMatrix)

    return out
  }
}

module.exports = Camera
