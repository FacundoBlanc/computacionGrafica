let glMatrix = require('gl-matrix')
let modelMatrix = glMatrix.mat4.create()
let quatMatrix = glMatrix.mat4.create()
let q = glMatrix.quat.create()

class Mesh {
  constructor (geometry, material, tx = 0, ty = 0, tz = 0, rx = 0, ry = 0, rz = 0, sx = 1, sy = 1, sz = 1) {
    this.geometry = geometry
    this.material = material
    this.tx = tx
    this.ty = ty
    this.tz = tz
    this.rx = rx
    this.ry = ry
    this.rz = rz
    this.sx = sx
    this.sy = sy
    this.sz = sz
    this.VertexBO = geometry.vertices
    this.IndexBO = geometry.indices
  }

  addMesh (mesh) {
    this.mesh = mesh
  }

  getModelMatrix () {
    glMatrix.mat4.identity(modelMatrix)

    // translate
    glMatrix.mat4.translate(modelMatrix, modelMatrix, [this.tx, this.ty, this.tz])

    // rotate with quaternions
    glMatrix.quat.fromEuler(q, this.rx, this.ry, this.rz)
    glMatrix.mat4.fromQuat(quatMatrix, q)
    glMatrix.mat4.multiply(modelMatrix, modelMatrix, quatMatrix)

    // rotate
    // glMatrix.mat4.rotate(modelMatrix, modelMatrix, this.rx, [1, 0, 0])
    // glMatrix.mat4.rotate(modelMatrix, modelMatrix, this.ry, [0, 1, 0])
    // glMatrix.mat4.rotate(modelMatrix, modelMatrix, this.rz, [0, 0, 1])

    // scale
    glMatrix.mat4.scale(modelMatrix, modelMatrix, [this.sx, this.sy, this.sz])

    return modelMatrix
  }
}

module.exports = Mesh
