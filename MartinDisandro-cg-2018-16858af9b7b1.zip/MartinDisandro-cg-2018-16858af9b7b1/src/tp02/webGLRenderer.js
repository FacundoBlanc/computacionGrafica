var vsSource = require('./shaders/vertex-shader.glsl')
var fsSource = require('./shaders/fragment-shader.glsl')

class WebGLRenderer {
  constructor (canvas) {
    canvas.width = 400
    canvas.height = 400
    this.gl = canvas.getContext('webgl')
    if (!this.gl) {
      console.log('Failed to get the rendering context for WebGL')
    }
  }

  render (scene) {
    var mesh = scene.meshes[0]
    let gl = this.gl
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height)

    let [r, g, b, a] = scene.clearColor
    gl.clearColor(r, g, b, a)
    // Clear <canvas>
    gl.clear(gl.COLOR_BUFFER_BIT)

    var vertexShader = gl.createShader(gl.VERTEX_SHADER)
    gl.shaderSource(vertexShader, vsSource)
    gl.compileShader(vertexShader)

    var fragmentShader = gl.createShader(gl.FRAGMENT_SHADER)
    gl.shaderSource(fragmentShader, fsSource)
    gl.compileShader(fragmentShader)

    var program = gl.createProgram()
    gl.attachShader(program, vertexShader)
    gl.attachShader(program, fragmentShader)

    gl.linkProgram(program)
    gl.useProgram(program)

    // Cache attribute/uniform location
    var aPosition = gl.getAttribLocation(program, 'aPosition')
    gl.enableVertexAttribArray(aPosition)
    var uColor = gl.getUniformLocation(program, 'uColor')

    // Create Vertex Buffer Object
    var bufferVBO = gl.createBuffer()
    gl.bindBuffer(gl.ARRAY_BUFFER, bufferVBO)
    // Populate Buffer Object
    gl.bufferData(gl.ARRAY_BUFFER, mesh.vertexBO, gl.STATIC_DRAW)
    // Bind Buffer to a shader attribute
    gl.vertexAttribPointer(
      aPosition, 2, gl.FLOAT, false,
      mesh.vertexBO.BYTES_PER_ELEMENT * 0, mesh.vertexBO.BYTES_PER_ELEMENT * 0
    )
    // Clean up
    gl.bindBuffer(gl.ARRAY_BUFFER, null)

    var polygonColor = new Float32Array(mesh.material)
    // console.log('material: ', mesh.material)

    gl.uniform4fv(uColor, polygonColor)

    // Create Index Buffer Object
    var bufferIBO = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, bufferIBO)
    // gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, polygonIBOData, gl.STATIC_DRAW)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, mesh.indexBO, gl.STATIC_DRAW)
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null)

    // Draw Triangle
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, bufferIBO)
    gl.drawElements(gl.TRIANGLES, mesh.indexBO.length, gl.UNSIGNED_SHORT, 0)
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null)

    // Free buffered memory
    gl.deleteBuffer(bufferVBO)
    gl.deleteBuffer(bufferIBO)
  }
}

module.exports = WebGLRenderer
