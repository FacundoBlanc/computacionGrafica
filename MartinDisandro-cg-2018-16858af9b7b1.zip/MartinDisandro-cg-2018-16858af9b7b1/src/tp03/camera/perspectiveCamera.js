const Camera = require('./camera')
const glMatrix = require('gl-matrix')
let out = glMatrix.mat4.create()

class PerspectiveCamera extends Camera {
  constructor (fovy = Math.PI / 4, aspect = 16 / 9, near = 0.001, far = 1000) {
    super()
    this.fovy = fovy
    this.aspect = aspect
    this.near = near
    this.far = far
  }
  getProjectionMatrix () {
    glMatrix.mat4.perspective(out, this.fovy, this.aspect, this.near, this.far)
    // roll, pitch, yaw
    // let q = glMatrix.quat.create()
    // glMatrix.quat.fromEuler(q, this.rx, this.ry, this.rz)
    // glMatrix.mat4.fromQuat(modelMatrix, q)

    return out
  }
}

module.exports = PerspectiveCamera
