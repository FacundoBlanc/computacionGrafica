const RGB = require('./rgb')

class Hex extends RGB {
  constructor (hexNumber) {
    hexNumber = Math.floor(hexNumber)
    let r = (hexNumber >> 16 & 255) / 255
    let g = (hexNumber >> 8 & 255) / 255
    let b = (hexNumber & 255) / 255
    super(r, g, b)
  }
}

module.exports = Hex
