class Geometry {
  constructor (vertices, indices, normals) {
    this.vertices = vertices
    this.indices = indices
    this.normals = normals
  }
}

module.exports = Geometry
