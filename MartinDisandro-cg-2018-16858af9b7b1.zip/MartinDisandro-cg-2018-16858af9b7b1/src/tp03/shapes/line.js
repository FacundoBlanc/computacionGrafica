const Geometry = require('../geometry')
class Line extends Geometry {
  constructor (vertices, indices = [0, 1]) {
    super(vertices, indices)
  }
}

module.exports = Line
