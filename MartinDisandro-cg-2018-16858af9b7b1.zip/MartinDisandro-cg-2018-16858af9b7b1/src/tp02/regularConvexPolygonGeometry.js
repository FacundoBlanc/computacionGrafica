const Geometry = require('./geometry')

class RegularConvexPolygonGeometry extends Geometry {
  constructor (edges) {
    let alfa = 0
    const grados = 360 / edges
    let v = []

    for (let i = 0; i < edges * 2; i += 2) {
      v[i] = Math.cos(Math.PI * alfa / 180.0)
      v[i + 1] = Math.sin(Math.PI * alfa / 180.0)
      alfa += grados
    }
    // console.log(grados)
    // console.log(vertices)
    super(v, 1)
  }
}
module.exports = RegularConvexPolygonGeometry
