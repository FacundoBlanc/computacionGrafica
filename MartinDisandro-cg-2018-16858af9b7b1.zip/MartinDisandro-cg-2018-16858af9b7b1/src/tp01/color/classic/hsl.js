const RGBA = require('./rgba')

class HSL extends RGBA {
  constructor (h, s, l) {
    var r, g, b
    h /= 360
    if (s === 0) {
      r = g = b = l // achromatic
    } else {
      var hue2rgb = function (p, q, t) {
        if (t < 0) t += 1
        if (t > 1) t -= 1
        if (t < 1 / 6) return p + (q - p) * 6 * t
        if (t < 1 / 2) return q
        if (t < 2 / 3) return p + (q - p) * 6 * (2 / 3 - t)
        return p
      }

      var q = l < 0.5 ? l * (1 + s) : l + s - (l * s)
      var p = (2 * l) - q
      r = hue2rgb(p, q, h + 1 / 3)
      g = hue2rgb(p, q, h)
      b = hue2rgb(p, q, h - 1 / 3)
    }
    r = Math.round(r)
    g = Math.round(g)
    b = Math.round(b)
    console.log('r: ' + r + ', g: ' + g + ', b: ' + b)
    super(r, g, b, 1)
  }
}

module.exports = HSL
