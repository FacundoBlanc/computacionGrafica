class Light {
  constructor (color, active = true) {
    this.color = [color[0] * 255, color[1] * 255, color[2] * 255]
    this.active = active
  }
}
// 20 ambiente
// 50-70 difusa
// 100 especular
module.exports = Light
