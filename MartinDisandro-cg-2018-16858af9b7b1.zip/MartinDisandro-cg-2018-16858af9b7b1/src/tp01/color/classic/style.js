const Hex = require('./hex')

class Style extends Hex {
  constructor (styleString) {
    let hexString = styleString.slice(1)
    if (hexString.length === 3) {
      hexString = hexString.charAt(0) + hexString.charAt(0) +
      hexString.charAt(1) + hexString.charAt(1) +
      hexString.charAt(2) + hexString.charAt(2)
    }
    super(parseInt(hexString, 16))
  }
}

module.exports = Style
