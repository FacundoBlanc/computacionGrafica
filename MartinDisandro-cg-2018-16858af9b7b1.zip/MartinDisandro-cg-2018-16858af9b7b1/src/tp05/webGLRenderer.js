var vs = require('./shaders/vs.glsl')
var fs = require('./shaders/fs.glsl')
// var vsLight = require('./shaders/vs_light.glsl')
// var fsLight = require('./shaders/fs_light.glsl')
var vsTexture = require('./shaders/vs_textures.glsl')
var fsTexture = require('./shaders/fs_textures.glsl')
const twgl = require('twgl.js')

class WebGLRenderer {
  constructor (canvas) {
    // canvas.width = window.innerWidth
    // canvas.height = window.innerHeight
    this.gl = twgl.getWebGLContext(document.getElementById('c'))
    this.programInfo = twgl.createProgramInfo(this.gl, [vs, fs])
    // this.programLight = twgl.createProgramInfo(this.gl, [vsLight, fsLight])
    this.programTexture = twgl.createProgramInfo(this.gl, [vsTexture, fsTexture])
    if (!this.gl) {
      console.log('Failed to get the rendering context for WebGL')
    }
    // this.floor = true
    // this.cube = false
    // this.cylinder = false
    // this.sphere = false
    //
    this.arrays = {}
    this.bufferInfo = ''
    this.uniforms = {}
    // PICKING
    this.framebufferInfo = ''
    const contextReference = this
    this.gl.canvas.addEventListener('click', function (evt) {
      contextReference.pickingCoord = {
        x: evt.offsetX,
        y: contextReference.gl.canvas.height - evt.offsetY
      }
      console.log(contextReference.pickingCoord)
    })
  }

  render (scene, camera) {
    this.gl.clearColor(...scene.clearColor)
    this.gl.enable(this.gl.DEPTH_TEST)
    this.gl.clear(this.gl.COLOR_BUFFER_BIT | this.gl.DEPTH_BUFFER_BIT)
    twgl.resizeCanvasToDisplaySize(this.gl.canvas)
    this.gl.viewport(0, 0, this.gl.drawingBufferWidth, this.gl.drawingBufferHeight)
    // this.gl.viewport(0, 0, window.innerWidth, window.innerHeight)
    this.framebufferInfo = this.createFramebufferInfo(this.gl)
    let mesh
    const figureNumber = 45
    // let i
    for (let i = 0; i < figureNumber; i++) {
      mesh = scene.meshes[i]
      this.draw(mesh.geometry.vertices, mesh.geometry.indices,
        mesh.material, camera, mesh.getModelMatrix(), this.gl.LINES)
    }
    // Figures
    for (let i = figureNumber; i < figureNumber + 4; i++) {
      let mesh = scene.meshes[i]
      if (mesh.active) {
        this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
        if (mesh.enableAxes) {
          this.draw([0, 0, 0, 3, 0, 0], [0, 1], [1, 0, 0], camera, mesh.getModelMatrix(), this.gl.LINES)
          this.draw([0, 0, 0, 0, 3, 0], [0, 1], [0, 1, 0], camera, mesh.getModelMatrix(), this.gl.LINES)
          this.draw([0, 0, 0, 0, 0, 3], [0, 1], [0, 0, 1], camera, mesh.getModelMatrix(), this.gl.LINES)
        }
      }
    }
    if (this.pickingCoord != null) {
      this.pickedColor(scene, camera)
    }
    // if (this.floor) {
    //   mesh = scene.meshes[figureNumber]
    //   this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
    // }
    // if (this.cube) {
    //   mesh = scene.meshes[figureNumber + 1]
    //   this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
    // }
    // if (this.cylinder) {
    //   mesh = scene.meshes[figureNumber + 2]
    //   this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
    // }
    // if (this.sphere) {
    //   mesh = scene.meshes[figureNumber + 3]
    //   this.drawLight(mesh, camera, scene, this.gl.TRIANGLES)
    // }
    // *************************************************************
    // POINT LIGHT ORB
    if (scene.pointLights[0].active) {
      mesh = scene.meshes[figureNumber + 4]
      mesh.setPosition([scene.pointLights[0].px, scene.pointLights[0].py, scene.pointLights[0].pz])
      mesh.material = scene.pointLights[0].specular
      this.draw(mesh.geometry.vertices, mesh.geometry.indices,
        mesh.material, camera, mesh.getModelMatrix(), this.gl.TRIANGLES)
    }

    if (scene.pointLights[1].active) {
      mesh = scene.meshes[figureNumber + 5]
      mesh.setPosition([scene.pointLights[1].px, scene.pointLights[1].py, scene.pointLights[1].pz])
      mesh.material = scene.pointLights[1].specular
      this.draw(mesh.geometry.vertices, mesh.geometry.indices,
        mesh.material, camera, mesh.getModelMatrix(), this.gl.TRIANGLES)
    }
    // SPOT LIGHT ORB
    if (scene.spotLight.active) {
      mesh = scene.meshes[figureNumber + 6]
      mesh.setPosition([scene.spotLight.px, scene.spotLight.py, scene.spotLight.pz])
      mesh.material = scene.spotLight.specular

      this.draw(mesh.geometry.vertices, mesh.geometry.indices,
        mesh.material, camera, mesh.getModelMatrix(), this.gl.TRIANGLES)
    }
  }

  draw (aPosition, indices, color, camera, modelMatrix, glType) {
    this.arrays = {
      aPosition: aPosition,
      indices: indices
    }
    this.bufferInfo = twgl.createBufferInfoFromArrays(this.gl, this.arrays)
    this.uniforms = {
      uColor: color,
      uViewMatrix: camera.getViewMatrix(),
      uProjectionMatrix: camera.getProjectionMatrix(),
      uModelMatrix: modelMatrix,
    }

    this.gl.useProgram(this.programInfo.program)
    twgl.setBuffersAndAttributes(this.gl, this.programInfo, this.bufferInfo)
    twgl.setUniforms(this.programInfo, this.uniforms)
    twgl.drawBufferInfo(this.gl, this.bufferInfo, glType)
  }

  drawLight (mesh, camera, scene, glType) {
    this.arrays = {
      aPosition: mesh.geometry.vertices,
      aNormal: mesh.geometry.normals,
      indices: mesh.geometry.indices,
      aTexCoords: mesh.geometry.st
    }
    this.bufferInfo = twgl.createBufferInfoFromArrays(this.gl, this.arrays)
    if (mesh.tex === undefined) {
      mesh.tex = twgl.createTexture(this.gl, {
        src: require('' + mesh.material.map)
      })
      this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, true)
    }

    this.uniforms = {
      // Vertex Shader
      uModelMatrix: mesh.getModelMatrix(),
      uNormalMatrix: mesh.getNormalMatrix(),
      uViewMatrix: camera.getViewMatrix(),
      uProjectionMatrix: camera.getProjectionMatrix(),
      // Fragment Shader
      uViewPos: camera.eyeView,

      'material.texture': mesh.tex,
      'material.useTexture': mesh.material.useTexture,

      // uPickingColor = mesh.pickingColor
      'material.diffuse': mesh.material.diffuse,
      'material.specular': mesh.material.specular,
      'material.shininess': mesh.material.shininess,

      'ambientLight.active': scene.ambientLight.active,
      'ambientLight.color': scene.ambientLight.ambient,

      'dirLight.active': scene.directionalLight.active,
      'dirLight.direction': [scene.directionalLight.px, scene.directionalLight.py, scene.directionalLight.pz],
      'dirLight.ambient': scene.directionalLight.ambient,
      'dirLight.diffuse': scene.directionalLight.diffuse,
      'dirLight.specular': scene.directionalLight.specular,

      'pointLights[0].active': scene.pointLights[0].active,
      'pointLights[0].position': [scene.pointLights[0].px, scene.pointLights[0].py, scene.pointLights[0].pz],
      'pointLights[0].ambient': scene.pointLights[0].ambient,
      'pointLights[0].diffuse': scene.pointLights[0].diffuse,
      'pointLights[0].specular': scene.pointLights[0].specular,
      'pointLights[0].constant': scene.pointLights[0].constant,
      'pointLights[0].linear': scene.pointLights[0].linear,
      'pointLights[0].quadratic': scene.pointLights[0].quadratic,

      'pointLights[1].active': scene.pointLights[1].active,
      'pointLights[1].position': [scene.pointLights[1].px, scene.pointLights[1].py, scene.pointLights[1].pz],
      'pointLights[1].ambient': scene.pointLights[1].ambient,
      'pointLights[1].diffuse': scene.pointLights[1].diffuse,
      'pointLights[1].specular': scene.pointLights[1].specular,
      'pointLights[1].constant': scene.pointLights[1].constant,
      'pointLights[1].linear': scene.pointLights[1].linear,
      'pointLights[1].quadratic': scene.pointLights[1].quadratic,

      'spotLight.active': scene.spotLight.active,
      'spotLight.position': [scene.spotLight.px, scene.spotLight.py, scene.spotLight.pz],
      'spotLight.direction': [scene.spotLight.dx, scene.spotLight.dy, scene.spotLight.dz],
      'spotLight.cutOff': scene.spotLight.getCutOff(),
      'spotLight.outerCutOff': scene.spotLight.getOuterCutOff(),
      'spotLight.ambient': scene.spotLight.ambient,
      'spotLight.diffuse': scene.spotLight.diffuse,
      'spotLight.specular': scene.spotLight.specular,
      'spotLight.constant': scene.spotLight.constant,
      'spotLight.linear': scene.spotLight.linear,
      'spotLight.quadratic': scene.spotLight.quadratic
    }
    this.gl.useProgram(this.programTexture.program)
    twgl.setBuffersAndAttributes(this.gl, this.programTexture, this.bufferInfo)
    twgl.setUniforms(this.programTexture, this.uniforms)
    twgl.drawBufferInfo(this.gl, this.bufferInfo, glType)
  }

  createFramebufferInfo (gl) {
    const attachments = [
      {
        format: gl.RGBA,
        type: gl.UNSIGNED_BYTE,
        min: gl.LINEAR,
        mag: gl.LINEAR,
        wrap: gl.CLAMP_TO_EDGE
      },
      {
        format: gl.DEPTH_COMPONENT16
      }
    ]

    const framebufferInfo = twgl.createFramebufferInfo(gl, attachments, gl.drawingBufferWidth, gl.drawingBufferHeight)
    gl.bindFramebuffer(gl.FRAMEBUFFER, null)

    return framebufferInfo
  }

  printPickedMesh (readout, meshes) {
    meshes.forEach((mesh) => {
      if (mesh.id === readout[0]) {
        console.log(`ID ${mesh.id}`)
        console.log(mesh.geometry)
        mesh.enableAxes = !mesh.enableAxes
        // console.log('Set a flag or something to signal that this mesh was picked', mesh.geometry)
      }
    })
  }

  pickedColor (scene, camera) {
    let readout = new Uint8Array(1 * 1 * 4)
    this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, this.framebufferInfo.framebuffer)

    for (let i = 45; i < 49; i++) {
      let mesh = scene.meshes[i]
      if (mesh.active) {
        // console.log('id', mesh.pickingColor)
        this.draw(mesh.geometry.vertices, mesh.geometry.indices,
          mesh.pickingColor, camera, mesh.getModelMatrix(), this.gl.TRIANGLES)
      }
    }
    // read one pixel
    this.gl.readPixels(this.pickingCoord.x, this.pickingCoord.y, 1, 1,
      this.gl.RGBA, this.gl.UNSIGNED_BYTE, readout)
    this.gl.bindFramebuffer(this.gl.FRAMEBUFFER, null)

    console.log('picked color', readout)
    this.printPickedMesh(readout, scene.meshes)
    this.pickingCoord = null
  }
}

module.exports = WebGLRenderer
