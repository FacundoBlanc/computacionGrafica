var vs = require('./shaders/vs.glsl')
var fs = require('./shaders/fs.glsl')
const twgl = require('twgl.js')

class WebGLRenderer {
  constructor (canvas) {
    canvas.width = window.innerWidth
    canvas.height = window.innerHeight
    this.gl = twgl.getWebGLContext(document.getElementById('c'))
    this.programInfo = twgl.createProgramInfo(this.gl, [vs, fs])
    if (!this.gl) {
      console.log('Failed to get the rendering context for WebGL')
    }
    this.cube = false
    this.cylinder = false
    this.cone = false
    this.sphere = false
  }

  render (scene, camera) {
    let gl = this.gl
    gl.clearColor(...scene.clearColor)
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
    twgl.resizeCanvasToDisplaySize(gl.canvas)
    // gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight)
    gl.viewport(0, 0, window.innerWidth, window.innerHeight)

    let mesh
    let i
    for (i = 0; i < 45; i++) {
      mesh = scene.meshes[i]
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, mesh.material, camera, mesh.getModelMatrix(), gl.LINES)
    }
    if (this.cube) {
      mesh = scene.meshes[45]
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, mesh.material, camera, mesh.getModelMatrix(), gl.TRIANGLES)
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, [1, 0, 1], camera, mesh.getModelMatrix(), gl.LINE_LOOP)
    }
    if (this.cylinder) {
      mesh = scene.meshes[46]
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, mesh.material, camera, mesh.getModelMatrix(), gl.TRIANGLES)
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, [1, 0, 1], camera, mesh.getModelMatrix(), gl.LINE_LOOP)
    }
    if (this.cone) {
      mesh = scene.meshes[47]
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, mesh.material, camera, mesh.getModelMatrix(), gl.TRIANGLES)
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, [1, 0, 1], camera, mesh.getModelMatrix(), gl.LINE_LOOP)
    }
    if (this.sphere) {
      mesh = scene.meshes[48]
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, mesh.material, camera, mesh.getModelMatrix(), gl.TRIANGLES)
      this.draw(mesh.geometry.vertices, mesh.geometry.indices, [1, 0, 1], camera, mesh.getModelMatrix(), gl.LINE_LOOP)
    }
  }

  draw (aPosition, indices, color, camera, modelMatrix, glType) {
    let arrays = {
      aPosition: aPosition,
      indices: indices
    }
    let gl = this.gl
    let programInfo = this.programInfo
    // console.log('color: ', color)
    var bufferInfo = twgl.createBufferInfoFromArrays(gl, arrays)

    var uniforms = {
      uColor: color,
      uViewMatrix: camera.getViewMatrix(),
      uProjectionMatrix: camera.getProjectionMatrix(),
      uModelMatrix: modelMatrix
    }

    gl.useProgram(programInfo.program)
    twgl.setBuffersAndAttributes(gl, programInfo, bufferInfo)
    twgl.setUniforms(programInfo, uniforms)
    twgl.drawBufferInfo(gl, bufferInfo, glType)
  }
}

module.exports = WebGLRenderer
