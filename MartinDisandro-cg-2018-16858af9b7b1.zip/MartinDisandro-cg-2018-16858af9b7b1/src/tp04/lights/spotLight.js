const Light = require('./light')

class SpotLight extends Light {
  constructor (color, position, direction, active) {
    super(color, active)
    this.px = position[0]
    this.py = position[1]
    this.pz = position[2]

    this.dx = direction[0]
    this.dy = direction[1]
    this.dz = direction[2]

    this.focus = 1
    this.cutOff = 50
    this.outerCutOff = this.cutOff - this.focus

    this.constant = 1.0
    this.linear = 0.09
    this.quadratic = 0.032
  }
  get ambient () {
    return [this.color[0] * 0.2 / 255, this.color[1] * 0.2 / 255, this.color[2] * 0.2 / 255]
  }
  get diffuse () {
    return [this.color[0] * 0.5 / 255, this.color[1] * 0.5 / 255, this.color[2] * 0.5 / 255]
  }
  get specular () {
    return [this.color[0] / 255, this.color[1] / 255, this.color[2] / 255]
  }
  getCutOff () {
    return this.degToRad(this.cutOff)
  }
  getOuterCutOff () {
    return this.degToRad(this.cutOff - this.focus)
  }
  degToRad (d) {
    return d * 3.1415 / 180
  }
}

module.exports = SpotLight
