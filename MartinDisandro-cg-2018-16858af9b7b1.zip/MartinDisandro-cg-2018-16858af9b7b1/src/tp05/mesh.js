let glMatrix = require('gl-matrix')
let i = 1
class Mesh {
  constructor (geometry, material,
    keepTrace = false,
    tx = 0, ty = 0, tz = 0,
    rx = 0, ry = 0, rz = 0,
    sx = 1, sy = 1, sz = 1
  ) {
    this.geometry = geometry
    this.material = material
    this.tx = tx
    this.ty = ty
    this.tz = tz
    this.rx = rx
    this.ry = ry
    this.rz = rz
    this.sx = sx
    this.sy = sy
    this.sz = sz
    this.enable = false
    this.enableAxes = false
    this.modelMatrix = glMatrix.mat4.create()
    this.quatMatrix = glMatrix.mat4.create()
    this.q = glMatrix.quat.create()
    this.normalMatrix = glMatrix.mat4.create()
    this.id = null
    this.pickingColor = null
    if (keepTrace) {
      this.id = i++
      this.pickingColor = [this.id / 255, 0, 0]
      // console.log(this.id, this.pickingColor)
    }
  }

  set active (condicion) {
    this.enable = condicion
  }
  get active () {
    return this.enable
  }

  addMesh (mesh) {
    this.mesh = mesh
  }

  setPosition (position) {
    this.tx = position[0]
    this.ty = position[1]
    this.tz = position[2]
  }
  setRotation (rotation) {
    this.rx = rotation[0]
    this.ry = rotation[1]
    this.rz = rotation[2]
  }

  getModelMatrix () {
    glMatrix.mat4.identity(this.modelMatrix)

    // translate
    glMatrix.mat4.translate(this.modelMatrix, this.modelMatrix, [this.tx, this.ty, this.tz])

    // rotate with quaternions
    glMatrix.quat.fromEuler(this.q, this.rx, this.ry, this.rz)
    glMatrix.mat4.fromQuat(this.quatMatrix, this.q)
    glMatrix.mat4.multiply(this.modelMatrix, this.modelMatrix, this.quatMatrix)

    // rotate
    // glMatrix.mat4.rotate(modelMatrix, modelMatrix, this.rx, [1, 0, 0])
    // glMatrix.mat4.rotate(modelMatrix, modelMatrix, this.ry, [0, 1, 0])
    // glMatrix.mat4.rotate(modelMatrix, modelMatrix, this.rz, [0, 0, 1])

    // scale
    glMatrix.mat4.scale(this.modelMatrix, this.modelMatrix, [this.sx, this.sy, this.sz])

    return this.modelMatrix
  }
  // Normal Matrix
  getNormalMatrix () {
    // normalMatrix = transpose(inverse(modelMatrix));
    glMatrix.mat4.invert(this.normalMatrix, this.modelMatrix)
    glMatrix.mat4.transpose(this.normalMatrix, this.normalMatrix)

    return this.normalMatrix
  }
}

module.exports = Mesh
