const Camera = require('./camera')
const glMatrix = require('gl-matrix')
let out = glMatrix.mat4.create()

class OrthographicCamera extends Camera {
  constructor (left = -10, right = 10, bottom = -10, top = 10, near = 0.001, far = 1000) {
    super()
    this.left = left
    this.right = right
    this.bottom = bottom
    this.top = top
    this.near = near
    this.far = far
  }
  getProjectionMatrix () {
    glMatrix.mat4.ortho(out, this.right, this.left, this.bottom, this.top, this.near, this.far)
    return out
  }
}

module.exports = OrthographicCamera
