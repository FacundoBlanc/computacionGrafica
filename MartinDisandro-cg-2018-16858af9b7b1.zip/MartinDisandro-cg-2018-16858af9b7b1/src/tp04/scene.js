class Scene {
  constructor (clearColor, ambientLight, directionalLight, pointLights, spotLight) {
    this.clearColor = clearColor
    this.meshes = []
    this.ambientLight = ambientLight
    this.directionalLight = directionalLight
    this.pointLights = pointLights
    this.spotLight = spotLight
  }
  addMesh (mesh) {
    this.meshes.push(mesh)
  }
}

module.exports = Scene
