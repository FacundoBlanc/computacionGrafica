// NOTAS:
// Para cambiar la camara de Perspectica a Ortografica
// se debe comentar la linea 56 y descomentar la 57

console.log('tp03')
console.log('Para cambiar la camara de Perspectica a Ortografica')
console.log('se debe comentar la linea 56 y descomentar la 57')

const dat = require('dat.gui/build/dat.gui')
const WebGLRenderer = require('./webGLRenderer')
const Scene = require('./scene')
const Mesh = require('./mesh')
const PerspectiveCamera = require('./camera/perspectiveCamera')
const OrtographicCamera = require('./camera/ortographicCamera')
const Line = require('./shapes/line')
const Cylinder = require('./shapes/cylinder')
const Sphere = require('./shapes/sphere')

let canvas = document.getElementById('c')
canvas.width = window.innerWidth
canvas.height = window.innerHeight

// Handling Context Lost
canvas.addEventListener('webglcontextlost', function (event) {
  event.preventDefault()
}, false)
canvas.addEventListener(
  'webglcontextrestored', render, false)
// END Handling Context Lost

let webGLRenderer = new WebGLRenderer(canvas)
let scene = new Scene([0.1, 0.1, 0.1, 1])

// Grid
for (let i = -10; i <= 10; i++) {
  scene.addMesh(new Mesh(new Line([i, 0, -10, i, 0, 10]), [0.5, 0.5, 0.5]))
  scene.addMesh(new Mesh(new Line([-10, 0, i, 10, 0, i]), [0.5, 0.5, 0.5]))
}
// Axes
scene.addMesh(new Mesh(new Line([0, 0, 0, 10, 0, 0]), [1, 0, 0]))
scene.addMesh(new Mesh(new Line([0, 0, 0, 0, 10, 0]), [0, 1, 0]))
scene.addMesh(new Mesh(new Line([0, 0, 0, 0, 0, 10]), [0, 0, 1]))
// Mesh 45
// Cube, mesh 45
scene.addMesh(new Mesh(new Cylinder(4), [1, 1, 0]))
// Cylinder, mesh 46
scene.addMesh(new Mesh(new Cylinder(32), [0, 0.5, 0.5]))
// Cone, mesh 47
scene.addMesh(new Mesh(new Cylinder(32, false), [0.5, 1, 0]))
// Sphere, mesh 48
scene.addMesh(new Mesh(new Sphere(24), [1, 0.5, 0]))

// Camaras
let perspectiveCamera = new PerspectiveCamera()
let ortographicCamera = new OrtographicCamera()

// SELECCION de CAMARA, Comentar linea correspondiente
let camera = perspectiveCamera
// let camera = ortographicCamera

// GUI
let gui = new dat.GUI({ width: 300 })
let figureName = ['Cube', 'Cylinder', 'Cone', 'Sphere']

for (let i = 45; i < scene.meshes.length; i++) {
  gui.add(webGLRenderer, figureName[i - 45].toLowerCase())
  let figureFolder = gui.addFolder(figureName[i - 45])

  figureFolder.add(scene.meshes[i], 'tx', -10, 10, 1)
  figureFolder.add(scene.meshes[i], 'ty', -10, 10, 1)
  figureFolder.add(scene.meshes[i], 'tz', -10, 10, 1)

  figureFolder.add(scene.meshes[i], 'sx', 0, 10, 1)
  figureFolder.add(scene.meshes[i], 'sy', 0, 10, 1)
  figureFolder.add(scene.meshes[i], 'sz', 0, 10, 1)

  figureFolder.add(scene.meshes[i], 'rx', 0, 360, 1)
  figureFolder.add(scene.meshes[i], 'ry', 0, 360, 1)
  figureFolder.add(scene.meshes[i], 'rz', 0, 360, 1)
}

let persCam = gui.addFolder('Perspective')
persCam.add(perspectiveCamera, 'fovy', Math.PI / 180, Math.PI / 2, Math.PI / 180)
persCam.add(perspectiveCamera, 'aspect', 0.1, 5, 0.1)
persCam.add(perspectiveCamera, 'near', 0.001, 10, 0.1)
persCam.add(perspectiveCamera, 'far', 5, 1005, 10)

let orthoCam = gui.addFolder('Orthographic')
orthoCam.add(ortographicCamera, 'left', -10, 0, 1)
orthoCam.add(ortographicCamera, 'right', 0, 10, 1)
orthoCam.add(ortographicCamera, 'bottom', -10, 0, 1)
orthoCam.add(ortographicCamera, 'top', 0, 10, 1)
orthoCam.add(ortographicCamera, 'near', 0.001, 10, 0.1)
orthoCam.add(ortographicCamera, 'far', 11, 1000, 1)

let cam = gui.addFolder('Camera')
cam.add(camera, 'eyeX', 0, 10, 1)
cam.add(camera, 'eyeY', 0, 10, 1)
cam.add(camera, 'eyeZ', 0, 10, 1)
cam.add(camera, 'centerX', -10, 10, 1)
cam.add(camera, 'centerY', -10, 10, 1)
cam.add(camera, 'centerZ', -10, 10, 1)
cam.add(camera, 'upX', -10, 10, 1)
cam.add(camera, 'upY', -10, 10, 1)
cam.add(camera, 'upZ', -10, 10, 1)

let camExtras = gui.addFolder('Camera moves')
camExtras.add(camera, 'distance', 0.1, 3, 0.1)
camExtras.add(camera, 'pitch', 0, 360, 1)
camExtras.add(camera, 'yaw', 0, 360, 1)
camExtras.add(camera, 'roll', 0, 360, 1)

// LOOP Renderizado

function render (time) {
  webGLRenderer.render(scene, camera)
  window.requestAnimationFrame(render)
}
window.requestAnimationFrame(render)
