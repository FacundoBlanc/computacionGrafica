const Geometry = require('../geometry')
class Floor extends Geometry {
  constructor () {
    const vertices = [
      5.0, 0.0, 5.0,
      5.0, 0.0, -5.0,
      -5.0, 0.0, -5.0,
      -5.0, 0.0, 5.0
    ]
    const indices = [
      0, 1, 2,
      0, 2, 3
    ]
    const normals = [
      0.0, 1.0, 0.0,
      0.0, 1.0, 0.0,
      0.0, 1.0, 0.0,
      0.0, 1.0, 0.0
    ]
    super(vertices, indices, normals)
  }
}

module.exports = Floor
