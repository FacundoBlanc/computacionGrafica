const RegularConvexPolygonGeometry = require('../regularConvexPolygonGeometry')
const Geometry = require('../geometry')
const Vec3 = require('../vec3')

class CylinderX extends Geometry {
  constructor () {
    const edgesOfFace = 4
    // const height = Math.sqrt(2) / 2
    const height = 1
    let bottom = new RegularConvexPolygonGeometry(edgesOfFace, -height)
    let top = new RegularConvexPolygonGeometry(edgesOfFace, height)

    let indices = []
    indices.push(...bottom.indices)
    for (let i = 0; i < top.indices.length; i++) {
      indices.push(top.indices[i] + edgesOfFace)
    }

    for (let i = 0; i < edgesOfFace; i++) {
      indices.push(i)
      indices.push(i + edgesOfFace)
      indices.push(i === edgesOfFace - 1 ? edgesOfFace : i + edgesOfFace + 1)

      indices.push(i)
      indices.push(i === edgesOfFace - 1 ? edgesOfFace : i + edgesOfFace + 1)
      indices.push(i === edgesOfFace - 1 ? 0 : i + 1)
    }

    let vertices = []
    vertices.push(...bottom.vertices) // 12
    vertices.push(...top.vertices) // 24 total

    // let index = []
    // index.push(...indices)
    // console.log('index', index)

    const offset = edgesOfFace * 3
    // let k = 0
    for (let c = 8, k = 0, i = offset; i < indices.length; i++, k++, c++) {
      if (k === 3 || k === 4) {
        indices[i] = k === 3 ? (c - 3) : (c - 2)
        continue
      } else {
        indices[i] = c
      }
      vertices.push(vertices[indices[i]])
      vertices.push(vertices[indices[i] + 1])
      vertices.push(vertices[indices[i] + 2])
      if (k === 5) {
        indices[i] = c - 2
        c -= 2
        k = -1
      }
    }

    let normals = []
    // for (let i = 0; i < edgesOfFace; i++) {
    //   normals.push(...[0, -1, 0])
    // }
    // for (let i = 0; i < edgesOfFace; i++) {
    //   normals.push(...[0, 1, 0])
    // }
    for (let i = 0; i < vertices.length; i += 4) {
      normals.push(
        ...Vec3.normal(
          [
            vertices[i + 0],
            vertices[i + 1],
            vertices[i + 2]
          ], [
            vertices[i + 3],
            vertices[i + 4],
            vertices[i + 5]
          ], [
            vertices[i + 6],
            vertices[i + 7],
            vertices[i + 8]
          ]
        )
      )
      normals.push(
        ...Vec3.normal(
          vertices[indices[i]],
          vertices[indices[i] + 2],
          vertices[indices[i] + 3]
        )
      )
    }
    // for (let i = 0; i < edgesOfFace; i++) {
    //   normals.push(...[0, -1, 0])
    // }
    // for (let i = 0; i < edgesOfFace; i++) {
    //   normals.push(...[0, 1, 0])
    // }
    // console.log('N-normals', offset)
    // for (let i = offset; i < vertices.length; i += 3) {
    //   normals.push(
    //     ...Vec3.normalize([
    //       vertices[indices[i]],
    //       0,
    //       vertices[indices[i] + 2]
    //     ])
    //   )
    // }

    console.log('vertices', vertices)
    console.log('indices', indices)
    console.log('normals', normals)
    super(vertices, indices, normals)
  }
}

module.exports = Cylinder
